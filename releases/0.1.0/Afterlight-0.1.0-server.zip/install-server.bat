@echo off
cd /d "%~dp0"
py -3 tools\setup_server.py
pause
